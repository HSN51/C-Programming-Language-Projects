﻿#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <queue>
#include <functional>
#include <sstream>
#include <locale> // locale kütüphanesi eklendi

using namespace std;

// Arac sınıfı oluşturup arac özelliklerini burada gösterdik
class Arac {
public:
	int id;
	string ariza_tur;
	int tamir_sure;
	int giris_saat;
	int bekleme_saat;
	int tamir_baslama_saat;
	int cikis_saat;

	Arac(int id, string ariza_tur, int tamir_sure, int giris_saat) {
		this->id = id;
		this->ariza_tur = ariza_tur;
		this->tamir_sure = tamir_sure;
		this->giris_saat = giris_saat;
		this->bekleme_saat = 0;
	}
	~Arac() {} // destructor
};

// Istasyon sınıfa her bir istasyonun özelliklerini ve durumunu tutar
class Istasyon {
public:
	string isim;
	queue<Arac*> araclar;
	int kapasite;
	int tamir_suresi;

	Istasyon(string isim, int kapasite, int tamir_kapasitesi) {
		this->isim = isim;
		this->kapasite = kapasite;
		this->tamir_suresi = tamir_kapasitesi;
	}

	// Istasyondaki ara�lar�n tamir işlemlerini gerçekleştirir
	void tamir_et(int sim_saat) {
		int tamamlanan_arac_sayisi = 0;
		while (!araclar.empty() && tamamlanan_arac_sayisi < kapasite) {
			Arac* arac = araclar.front();
			if (sim_saat >= arac->tamir_baslama_saat + arac->tamir_sure) {
				arac->cikis_saat = sim_saat;
				araclar.pop();
				tamamlanan_arac_sayisi++;
			}
			else {
				break;
			}
		}
	}

	// Istasyona yeni bir araç ekler
	bool arac_ekle(Arac* arac) {
		if (araclar.size() < kapasite) {
			araclar.push(arac);
			return true;
		}
		else {
			return false;
		}
	}
};

// BeklemeAlani s�n�f� ara�lar�n bekledi�i alandaki durumunu tutar
class BeklemeAlani {
public:
	priority_queue<Arac*, vector<Arac*>, function<bool(Arac*, Arac*)>> araclar;

	BeklemeAlani(function<bool(Arac*, Arac*)> cmp) : araclar(cmp) {}

	// Bekleme alan�na yeni bir ara� ekler
	void arac_ekle(Arac* arac) {
		araclar.push(arac);
	}

	// Bekleme alanından bir araç alır
	Arac* arac_al() {
		if (!araclar.empty()) {
			Arac* arac = araclar.top();
			araclar.pop();
			return arac;
		}
		else {
			return nullptr;
		}
	}
};

// SırayaAl fonksiyonu girdi veri dosyas�ndaki bilgileri okuyup, araçlara ilgili istasyonun bekleme alanına getirir
void SirayaAl(vector<Arac*>& araclar, BeklemeAlani& bekleyenler, const string& dosya_adi) {
	ifstream dosya(dosya_adi);
	if (dosya.is_open()) {
		string satir;
		int id = 1;
		while (getline(dosya, satir)) {
			string ariza_turu;
			int tamir_suresi, giris_saati;
			stringstream ss(satir);
			ss >> ariza_turu >> tamir_suresi >> giris_saati;
			Arac* arac = new Arac(id++, ariza_turu, tamir_suresi, giris_saati);
			araclar.push_back(arac);
			bekleyenler.arac_ekle(arac);
		}
		dosya.close();
	}
	else {
		cerr << "Hata: Dosya acilamadi!" << endl;
	}
}

// Sim�le fonksiyonu verilen istasyonlar� ve bekleyen araçlara alır, simulasyonu yapar ve sonuçlara ekrana yazar
void Simule(Istasyon& istasyon1, Istasyon& istasyon2, BeklemeAlani& bekleyenler, vector<Arac*>& araclar) {
	int sim_saat = 0;
	while (!bekleyenler.araclar.empty() || !araclar.empty() || !istasyon1.araclar.empty() || !istasyon2.araclar.empty()) {
		// Bekleyen ara�lar� ilgili istasyona y�nlendir
		while (!bekleyenler.araclar.empty()) {
			Arac* arac = bekleyenler.araclar.top();
			if (arac->giris_saat <= sim_saat) {
				if (arac->ariza_tur == "MOTOR") {
					if (istasyon1.arac_ekle(arac)) {
						arac->bekleme_saat = sim_saat - arac->giris_saat;
						bekleyenler.arac_al();
						arac->tamir_baslama_saat = sim_saat + istasyon1.tamir_suresi;
					}
					else {
						break;
					}
				}
				else if (arac->ariza_tur == "KAPI") {
					if (istasyon2.arac_ekle(arac)) {
						arac->bekleme_saat = sim_saat - arac->giris_saat;
						bekleyenler.arac_al();
						arac->tamir_baslama_saat = sim_saat + istasyon2.tamir_suresi;
					}
					else {
						break;
					}
				}
			}
			else {
				break;
			}
		}

		// Istasyonlardaki tamir işlemlerini ger�ekle�tir
		istasyon1.tamir_et(sim_saat);
		istasyon2.tamir_et(sim_saat);

		// Sim�lasyon saati ilerlet
		sim_saat++;

		// Tamir işlemi tamamlanan araçlara dosyaya yaz
		ofstream dosya("Arac.txt", ios::app);
		if (dosya.is_open()) {
			for (auto it = araclar.begin(); it != araclar.end();) {
				Arac* arac = *it;
				if (arac->cikis_saat > 0) {
					dosya << arac->id << " " << arac->ariza_tur << " " << arac->tamir_sure << " " << arac->giris_saat << " " << arac->bekleme_saat << " " << arac->tamir_baslama_saat << " " << arac->cikis_saat << endl;
					delete arac;
					it = araclar.erase(it);
				}
				else {
					++it;
				}
			}
			dosya.close();
		}
		else {
			cerr << "Hata: Dosya acilamadi!" << endl;
		}
	}
}

int main() {

	setlocale(LC_ALL, "Turkish");
	// Istasyonlar ve bekleme alanına oluştur
	Istasyon istasyon1("MOTOR", 2, 3);
	Istasyon istasyon2("KAPI", 1, 5);
	BeklemeAlani bekleyenler([](Arac* a, Arac* b) { return a->giris_saat > b->giris_saat; });

	// Girdi verilerini oku
	vector<Arac*> araclar;
	SirayaAl(araclar, bekleyenler, "C:\\Users\\bunya\\OneDrive\\Desktop\\Arac.txt");

	// Sim�lasyonu başlat
	Simule(istasyon1, istasyon2, bekleyenler, araclar);

	return 0;
}